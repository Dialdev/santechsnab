<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => 'ifEval

Snippet for comparison operations on TV, placeholders and other values.
Use the correct PHP code for input parameter, as the expression in the \'IF\' function in PHP.
IMPORTANT: This snippet uses PHP EVAL function. It should be used with careful security precautions.

Read code of snippet for examples

@ author Djordje Dimitrijev (dj13 on Modx forum)
@ version 0.9 beta1',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '90bacfe32405ff4f4e67a8f2a8cf8ae9',
      'native_key' => 'ifeval',
      'filename' => 'modNamespace/5a24d8ebfb96aa09c47823ead3c683b4.vehicle',
      'namespace' => 'ifeval',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c5124334ca919ab6aeb6f16984c310c8',
      'native_key' => 1,
      'filename' => 'modCategory/717c6fe6dde5613b464b8d6f01e15fe9.vehicle',
      'namespace' => 'ifeval',
    ),
  ),
);