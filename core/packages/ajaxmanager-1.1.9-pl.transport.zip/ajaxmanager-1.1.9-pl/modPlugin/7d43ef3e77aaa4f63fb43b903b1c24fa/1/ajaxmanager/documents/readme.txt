--------------------
Extra: AjaxManager
--------------------
Version: 1.1.9
Created: August 18th, 2014
Since: December 10th, 2012
Author: Danil Kostin <danya.postfactum@gmail.com>
License: GNU GPLv2 (or later at your option)

Minimal required MODx version is 2.2.7!

This plugin ajaxifies MODx Manager. No more page reloading and waiting for Tree appearing!

Works with modern browsers only (requires HTML5 History API).